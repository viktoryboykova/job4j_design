package ru.job4j;

/**
 * Hello world!
 *
 */
@SuppressWarnings("checkstyle:LeftCurly")
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
